var searchData=
[
  ['offerstate',['OfferState',['../classQXmppTransferJob.html#aab5bb06ca0d2c4f1fac33b7012d1c14fa0f5f5eec8a95f2faf27186dfd502f581',1,'QXmppTransferJob']]],
  ['online',['Online',['../classQXmppPresence.html#ad56af0f57b732c09b080b9347c4dba94a1285bac9669e2b48502a464f97dd85ee',1,'QXmppPresence']]],
  ['outgoingdirection',['OutgoingDirection',['../classQXmppCall.html#a429a4f8065136068b6d936cb2c803175a4959a53587ff3fe714b0c619dd8ba47d',1,'QXmppCall::OutgoingDirection()'],['../classQXmppTransferJob.html#a9c95a89a01357588f699e7d80c3de0b6adbfcc81360e31c1ded162fa244132bb7',1,'QXmppTransferJob::OutgoingDirection()']]]
];
