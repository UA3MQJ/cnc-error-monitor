var searchData=
[
  ['direction',['Direction',['../classQXmppCall.html#a429a4f8065136068b6d936cb2c803175',1,'QXmppCall::Direction()'],['../classQXmppTransferJob.html#a9c95a89a01357588f699e7d80c3de0b6',1,'QXmppTransferJob::Direction()']]]
];
