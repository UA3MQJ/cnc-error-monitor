var searchData=
[
  ['direction',['direction',['../classQXmppCall.html#a46873b89c65841319ed4a9ea9580df6e',1,'QXmppCall::direction()'],['../classQXmppTransferJob.html#ae38d5fe89922d7cdf702172f80d827e0',1,'QXmppTransferJob::direction()']]]
];
